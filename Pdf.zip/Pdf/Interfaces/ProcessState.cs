﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PdfConversionTool
{
    public class ProcessState
    {
        public int Success { get; set; }
        public int Failed { get; set; }

        public int Complete
        {
            get { return Success + Failed; }
        }

        public int Total { get; private set; }

        public ProcessState(int total)
        {
            Total = total;
        }

        public override string ToString()
        {
            return string.Format("{0}/{1}, Success:{2}, Failed:{3}", Complete, Total, Success, Failed);
        }
    }
}
