﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PdfConversionTool
{
    public interface IConversionProcessor
    {
        void Process(string file, string sourcePath, string targetPath);
        event EventHandler<ProcessEventArgs> Success;
        event EventHandler<ProcessEventArgs> Failed;
    }
}
