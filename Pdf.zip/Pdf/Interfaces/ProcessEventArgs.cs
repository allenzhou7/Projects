﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PdfConversionTool
{
    public class ProcessEventArgs : EventArgs
    {
        public ProcessEventArgs(string fileName)
        {
            FileName = fileName;
        }

        public ProcessEventArgs(string fileName, Exception error)
            : this(fileName)
        {
            Error = error;
        }

        public string FileName { get; private set; }
        public Exception Error { get; private set; }
    }
}
