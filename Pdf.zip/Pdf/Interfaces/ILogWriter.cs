﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PdfConversionTool
{
    public interface ILogWriter
    {
        void Write(Exception ex);
    }
}
