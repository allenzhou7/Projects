﻿namespace PdfConversionTool
{
    partial class MainWin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSource = new System.Windows.Forms.TextBox();
            this.btnOpenSourceFolder = new System.Windows.Forms.Button();
            this.btnOpenTargetFolder = new System.Windows.Forms.Button();
            this.txtTarget = new System.Windows.Forms.TextBox();
            this.btnConvert = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.filePanel = new System.Windows.Forms.Panel();
            this.filePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtSource
            // 
            this.txtSource.Location = new System.Drawing.Point(114, 16);
            this.txtSource.Name = "txtSource";
            this.txtSource.Size = new System.Drawing.Size(280, 20);
            this.txtSource.TabIndex = 0;
            // 
            // btnOpenSourceFolder
            // 
            this.btnOpenSourceFolder.Location = new System.Drawing.Point(400, 13);
            this.btnOpenSourceFolder.Name = "btnOpenSourceFolder";
            this.btnOpenSourceFolder.Size = new System.Drawing.Size(24, 23);
            this.btnOpenSourceFolder.TabIndex = 1;
            this.btnOpenSourceFolder.Text = "...";
            this.btnOpenSourceFolder.UseVisualStyleBackColor = true;
            this.btnOpenSourceFolder.Click += new System.EventHandler(this.btnOpenSourceFolder_Click);
            // 
            // btnOpenTargetFolder
            // 
            this.btnOpenTargetFolder.Location = new System.Drawing.Point(400, 60);
            this.btnOpenTargetFolder.Name = "btnOpenTargetFolder";
            this.btnOpenTargetFolder.Size = new System.Drawing.Size(24, 23);
            this.btnOpenTargetFolder.TabIndex = 3;
            this.btnOpenTargetFolder.Text = "...";
            this.btnOpenTargetFolder.UseVisualStyleBackColor = true;
            this.btnOpenTargetFolder.Click += new System.EventHandler(this.btnOpenTargetFolder_Click);
            // 
            // txtTarget
            // 
            this.txtTarget.Location = new System.Drawing.Point(114, 60);
            this.txtTarget.Name = "txtTarget";
            this.txtTarget.Size = new System.Drawing.Size(280, 20);
            this.txtTarget.TabIndex = 2;
            // 
            // btnConvert
            // 
            this.btnConvert.Location = new System.Drawing.Point(350, 170);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(75, 23);
            this.btnConvert.TabIndex = 4;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Source Folder :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Target Folder :";
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.ForeColor = System.Drawing.Color.Black;
            this.lblMessage.Location = new System.Drawing.Point(108, 170);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(0, 15);
            this.lblMessage.TabIndex = 7;
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(113, 128);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(310, 23);
            this.progressBar.TabIndex = 8;
            // 
            // filePanel
            // 
            this.filePanel.Controls.Add(this.txtTarget);
            this.filePanel.Controls.Add(this.txtSource);
            this.filePanel.Controls.Add(this.btnOpenSourceFolder);
            this.filePanel.Controls.Add(this.label2);
            this.filePanel.Controls.Add(this.btnOpenTargetFolder);
            this.filePanel.Controls.Add(this.label1);
            this.filePanel.Location = new System.Drawing.Point(1, 16);
            this.filePanel.Name = "filePanel";
            this.filePanel.Size = new System.Drawing.Size(456, 106);
            this.filePanel.TabIndex = 9;
            // 
            // MainWin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(494, 239);
            this.Controls.Add(this.filePanel);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.btnConvert);
            this.Name = "MainWin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PDF Conversion Tool";
            this.Load += new System.EventHandler(this.PdfConvertorMain_Load);
            this.filePanel.ResumeLayout(false);
            this.filePanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSource;
        private System.Windows.Forms.Button btnOpenSourceFolder;
        private System.Windows.Forms.Button btnOpenTargetFolder;
        private System.Windows.Forms.TextBox txtTarget;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Panel filePanel;
    }
}

