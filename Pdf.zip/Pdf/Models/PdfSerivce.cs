﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PdfConversionTool.ConverterService;

namespace PdfConversionTool
{
    public class PdfSerivce : IPdfSerivce
    {
        public byte[] ConvertHtmlToPdf(string html)
        {
            using (var client = new ConverterServiceClient())
            {
                return client.ConvertHtmlToPdf(html);
            }
        }

        public byte[] ConvertXmlToPdf(string xml)
        {
            using (var client = new ConverterServiceClient())
            {
                return client.ConvertXmlToPdf(xml, XmlType.FO);
            }
        }
    }
}
