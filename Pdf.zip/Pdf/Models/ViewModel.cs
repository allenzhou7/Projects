﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace PdfConversionTool
{
    public class ViewModel
    {
        private IView view;
        private ILogWriter logWriter;
        private IConversionProcessor processor;
        private ProcessState state;

        public ViewModel(IView view, ILogWriter logWriter, IConversionProcessor processor)
        {
            this.view = view;
            this.logWriter = logWriter;
            this.processor = processor;

            processor.Success += new EventHandler<ProcessEventArgs>(processor_Success);
            processor.Failed += new EventHandler<ProcessEventArgs>(processor_Failed);
        }

        void processor_Success(object sender, ProcessEventArgs e)
        {
            BackupFile("Archive", e.FileName);
            state.Success++;
            view.ReportStatus(state);
        }

        void processor_Failed(object sender, ProcessEventArgs e)
        {
            logWriter.Write(e.Error);
            BackupFile("Failed", e.FileName);
            state.Failed++;
            view.ReportStatus(state);
        }

        public void Convert()
        {
            var result = ValidateForm();

            if (!result.Valid)
            {
                view.ShowMessage(result.Error);
                return;
            }

            string[] files = Directory.GetFiles(view.SourcePath);
            if (files.Length <= 0)
            {
                view.ShowMessage("No files in the source folder.");
                return;
            }

            state = new ProcessState(files.Length);

            foreach (var file in files)
            {
                processor.Process(file, view.SourcePath, view.TargetPath);
            }
        }

        private ValidationResult ValidateForm()
        {
            Dictionary<string, string> paths = new Dictionary<string, string>()
            {
                {"Source Folder", view.SourcePath},
                {"Target Folder", view.TargetPath}
            };

            foreach (var item in paths)
            {
                if (string.IsNullOrWhiteSpace(item.Value))
                {
                    return new ValidationResult(false, string.Format("{0} is required.", item.Key));
                }

                if (!Directory.Exists(item.Value))
                {
                    return new ValidationResult(false, string.Format("Folder for {0} is not existing.", item.Key));
                }
            }

            return ValidationResult.ValidResult;
        }

        private void BackupFile(string subFolder, string fullFileName)
        {
            string archiveFolder = Path.Combine(view.TargetPath, subFolder);

            if (!Directory.Exists(archiveFolder))
            {
                Directory.CreateDirectory(archiveFolder);
            }

            string fileName = Path.GetFileName(fullFileName);
            string archiveFile = Path.Combine(archiveFolder, fileName);
            File.Move(fullFileName, archiveFile);
        }
    }
}
