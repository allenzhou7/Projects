﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PdfConversionTool
{
    public class FileExaminer : IFileExaminer
    {
        public const string FOTag = "<fo:root xmlns:fo='http://www.w3.org/1999/XSL/Format'>";
        public const string TableTag = "table";

        public ContentType Examine(string content)
        {
            if (string.IsNullOrWhiteSpace(content))
            {
                return ContentType.Unknown;
            }

            var temp = content.ToLower();

            if (temp.Contains(FOTag.ToLower()))
            {
                return ContentType.Xml;
            }
            else if(temp.Contains(TableTag))
            {
                return ContentType.Html;
            }

            return ContentType.Unknown;
        }
    }
}
