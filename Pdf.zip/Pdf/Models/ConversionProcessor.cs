﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace PdfConversionTool
{
    public class ConversionProcessor : IConversionProcessor
    {
        private Dictionary<ContentType, Func<string, byte[]>> converters;

        private IFileExaminer fileExaminer;
        private IPdfSerivce pdfService;

        public ConversionProcessor(IPdfSerivce pdfService, IFileExaminer fileExaminer)
        {
            this.pdfService = pdfService;
            this.fileExaminer = fileExaminer;

            InitConverters();
        }

        private void InitConverters()
        {
            converters = new Dictionary<ContentType, Func<string, byte[]>>()
            {
                {ContentType.Html, pdfService.ConvertHtmlToPdf},
                {ContentType.Xml, pdfService.ConvertXmlToPdf}
            };
        }

        private Func<string, byte[]> GetConverter(ContentType type)
        {
            if (!converters.ContainsKey(type))
            {
                throw new QCException("File type is not supported.");
            }

            return converters[type];
        }

        public void Process(string file, string sourcePath, string targetPath)
        {
            try
            {
                string fileContent = ReadFile(file);

                ContentType contentType = fileExaminer.Examine(fileContent);

                Func<string, byte[]> converter = GetConverter(contentType);

                byte[] result = converter(fileContent);

                SavePdfFile(result, file, targetPath);

                OnSuccess(new ProcessEventArgs(file));
            }
            catch (Exception ex)
            {
                OnFailed(new ProcessEventArgs(file, ex));
            }
        }

        private string ReadFile(string file)
        {
            using (StreamReader sr = new StreamReader(file, Encoding.UTF8))
            {
                return sr.ReadToEnd();
            }
        }

        private void SavePdfFile(byte[] pdfContent, string fullFileName, string targetFolder)
        {
            string fileName = Path.GetFileNameWithoutExtension(fullFileName);
            string fullTargetFileName = Path.Combine(targetFolder, string.Format("{0}.pdf", fileName));

            using (FileStream fileStream = new FileStream(fullTargetFileName, FileMode.Create))
            {
                fileStream.Write(pdfContent, 0, pdfContent.Length);
                fileStream.Flush();
            }
        }

        public event EventHandler<ProcessEventArgs> Success;

        protected virtual void OnSuccess(ProcessEventArgs args)
        {
            if(Success!= null)
            {
                Success(this, args);
            }
        }

        public event EventHandler<ProcessEventArgs> Failed;

        protected virtual void OnFailed(ProcessEventArgs args)
        {
            if (Failed != null)
            {
                Failed(this, args);
            }
        }
    }
}
