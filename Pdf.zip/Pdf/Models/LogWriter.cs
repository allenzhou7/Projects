﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;

namespace PdfConversionTool
{
    public class LogWriter : ILogWriter
    {
        public static ILogWriter Instance = new LogWriter();

        public void Write(Exception ex)
        {
            if (ex == null) throw new ArgumentNullException("ex");

            var content = ex.ToString();
            content = content.Replace("{", "{{").Replace("}", "}}");

            Write(content);
        }

        public void Write(string log, params object[] args)
        {
            string message = string.Format(log, args);

            StringBuilder builder = new StringBuilder();

            builder.AppendLine(new string('-', 50));
            builder.AppendLine("time: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            builder.AppendLine();
            builder.AppendLine();
            builder.AppendLine(message);
            builder.AppendLine();

            WriteToFile(builder.ToString());
        }

        private void WriteToFile(string message)
        {
            string logFilePath = GetFilePath();

            using (FileStream stream = File.Open(logFilePath, FileMode.Append))
            using (StreamWriter writer = new StreamWriter(stream))
            {
                writer.WriteLine(message);
            }
        }

        private string GetFilePath()
        {
            DateTime now = DateTime.Now;
            string directory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory
                , now.ToString("yyyy")
                , now.ToString("MM"));

            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            string filename = string.Format("log{0}.txt", now.ToString("dd"));
            string filePath = Path.Combine(directory, filename);

            return filePath;
        }
    }
}
