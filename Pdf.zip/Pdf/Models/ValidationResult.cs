﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PdfConversionTool
{
    public class ValidationResult
    {
        public bool Valid { get; set; }
        public string Error { get; set; }
        public static ValidationResult ValidResult = new ValidationResult(true, null);

        public ValidationResult(bool valid, string error)
        {
            this.Valid = valid;
            this.Error = error;
        }
    }
}
