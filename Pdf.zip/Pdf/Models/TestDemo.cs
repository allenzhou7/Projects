﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PdfConversionTool.Models
{
    class TestDemo
    {
        IConversion conversion;
        public TestDemo(IConversion conversion)
        {
            this.conversion = conversion;
        }

        public void Process()
        {

        }

        public Func<string, bool> GetProcess(string fileType)
        {
            if (fileType == "xml")
            {
                return this.conversion.ConvertToHtml;
            }
            else
            {
                return this.conversion.ConvertTXml;
            }
        }

    }

    class Conversion :IConversion 
    {

        public bool ConvertToHtml(string fileContent)
        {
            if (fileContent.Contains("table"))
            {
                return true;
            }
            return false;
        }

        public bool ConvertTXml(string fileContent)
        {
            if (fileContent.Contains("foo"))
            {
                return true;
            }
            return false;
        }
    }

    interface IConversion
    {
        bool ConvertToHtml(string fileContent);
        bool ConvertTXml(string fileContent);
    }
}
