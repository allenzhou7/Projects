﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace PdfConversionTool
{
    public partial class MainWin : Form, IView
    {
        public MainWin()
        {
            InitializeComponent();
        }

        private void PdfConvertorMain_Load(object sender, EventArgs e)
        {
        }

        private void btnOpenSourceFolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                txtSource.Text = dialog.SelectedPath;
            }
        }

        private void btnOpenTargetFolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                txtTarget.Text = dialog.SelectedPath;
            }
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            LockForm();
            ResetStatus();
            var processor = new ConversionProcessor(new PdfSerivce(), new FileExaminer());
            var viewModel = new ViewModel(this, LogWriter.Instance, processor);

            var thread = new Thread(() =>
            {
                try
                {
                    viewModel.Convert();
                }
                catch (Exception ex)
                {
                    LogWriter.Instance.Write(ex);
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    UnlockForm();
                }
            });

            thread.Start();
        }

        public string SourcePath
        {
            get { return txtSource.Text.Trim(); }
        }

        public string TargetPath
        {
            get { return txtTarget.Text.Trim(); }
        }

        public void ShowMessage(string message)
        {
            MessageBox.Show(message);
        }

        public void ReportStatus(ProcessState state)
        {
            var action = new Action(() =>
            {
                double value = ((double)state.Complete / state.Total) * progressBar.Maximum;
                progressBar.Value = (int)value;
                lblMessage.Text = state.ToString();
            });

            this.Invoke(action);
        }

        private void LockForm()
        {
            SetFormState(false);
        }

        private void ResetStatus()
        {
            progressBar.Value = 0;
            progressBar.Minimum = 0;
            progressBar.Maximum = 100;
            lblMessage.Text = string.Empty;
        }

        private void UnlockForm()
        {
            SetFormState(true);
        }

        private void SetFormState(bool enable)
        {
            var action = new Action(() =>
            {
                filePanel.Enabled = enable;
                btnConvert.Enabled = enable;
            });

            this.Invoke(action);
        }
    }
}
