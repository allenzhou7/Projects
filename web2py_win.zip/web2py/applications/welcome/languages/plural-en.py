#!/usr/bin/env python
{
# "singular form (0)": ["first plural form (1)", "second plural form (2)", ...],
'account': ['accounts'],
'book': ['books'],
'is': ['are'],
'man': ['men'],
'miss': ['misses'],
'person': ['people'],
'quark': ['quarks'],
'shop': ['shops'],
'this': ['these'],
'was': ['were'],
'woman': ['women'],
}
