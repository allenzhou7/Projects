﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ninesky.Models;
using Ninesky.Models.Ui;

namespace Ninesky.Repository
{
    public class CategoryRepository:RepositoryBase<Category>
    {
        /// <summary>
        /// 添加栏目
        /// </summary>
        /// <param name="category">栏目</param>
        /// <returns></returns>
        public override bool Add(Category category)
        {
            dbContext.Categorys.Add(category);
            return (dbContext.SaveChanges() > 0);
        }
        /// <summary>
        ///  更新栏目
        /// </summary>
        /// <param name="category">栏目</param>
        /// <returns></returns>
        public override bool Update(Category category)
        {
            dbContext.Categorys.Attach(category);
            dbContext.Entry<Category>(category).State = System.Data.EntityState.Modified;
            if (dbContext.SaveChanges() > 0) return true;
            else return false;
        }

        /// <summary>
        ///  删除栏目
        /// </summary>
        /// <param name="category">栏目</param>
        /// <returns></returns>
        public bool Delete(Category category)
        {
            dbContext.Categorys.Remove(category);
            if (dbContext.SaveChanges() > 0) return true;
            else return false;
        }
        /// <summary>
        /// 删除栏目
        /// </summary>
        /// <param name="CategoryId">栏目Id</param>
        /// <returns></returns>
        public override bool Delete(int CategoryId)
        {
            var _category = dbContext.Categorys.SingleOrDefault(c => c.CategoryId == CategoryId);
            if (_category == null) return false;
            else return Delete(_category);
        }

        /// <summary>
        ///  查找制定栏目
        /// </summary>
        /// <param name="CategoryId">栏目id</param>
        /// <returns></returns>
        public override Category Find(int CategoryId)
        {
            return dbContext.Categorys.SingleOrDefault(c => c.CategoryId == CategoryId);
        }
        /// <summary>
        /// 获取跟栏目
        /// </summary>
        /// <returns></returns>
        public IQueryable<Category> Root()
        {
            return Children(0);
        }
        /// <summary>
        /// 获取子栏目
        /// </summary>
        /// <param name="categoryId">栏目Id</param>
        /// <returns></returns>
        public IQueryable<Category> Children(int categoryId)
        {
            return dbContext.Categorys.Where(c => c.ParentId == categoryId).OrderBy(c => c.Order);
        }
        /// <summary>
        /// 获取子栏目
        /// </summary>
        /// <param name="categoryId">栏目id</param>
        /// <param name="type">栏目类型</param>
        /// <returns></returns>
        public IQueryable<Category> Children(int categoryId, int type)
        {
            return dbContext.Categorys.Where(c => c.ParentId == categoryId && c.Type == type).OrderBy(c => c.Order);
        }
        /// <summary>
        /// 栏目列表
        /// </summary>
        /// <param name="model">模型名称</param>
        /// <returns></returns>
        public IQueryable<Category> List(string model)
        {
            return dbContext.Categorys.Where(c => c.Model == model).OrderBy(c => c.Order);
        }
        /// <summary>
        /// 普通栏目树形类表
        /// </summary>
        /// <returns></returns>
        public List<Tree> TreeGeneral()
        {
            var _root = Children(0, 0).Select(c => new Tree { id = c.CategoryId, text = c.Name, iconCls = "icon-general" }).ToList();
            if (_root != null)
            {
                for (int i = 0; i < _root.Count(); i++)
                {
                    _root[i] = RecursionTreeGeneral(_root[i]);
                }
            }
            return _root;
        }
        /// <summary>
        /// 普通栏目树形类表递归函数
        /// </summary>
        /// <param name="tree"></param>
        /// <returns></returns>
        private Tree RecursionTreeGeneral(Tree tree)
        {
            var _children = Children(tree.id, 0).Select(c => new Tree { id = c.CategoryId, text = c.Name, iconCls="icon-general" }).ToList();
            if (_children != null)
            {
                
                for (int i = 0; i < _children.Count(); i++)
                {
                    _children[i] = RecursionTreeGeneral(_children[i]);
                }
                tree.children = _children;
            }
            return tree;
        }
    }
}